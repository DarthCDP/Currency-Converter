﻿using System;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Metadata.W3cXsd2001;

namespace Currency_Converter
{
    struct Currency
    {
        public string Name;         //Name will be the 3-digit representation (USD, CAD, Etc.)
        public string AmountString; //Value will be input as text intially
        public decimal Amount;      //Then converted to decimal so that we can do math with it
        public decimal Value;       
    };

    internal class Program
    {


        public static string html = "Null";     //Publicly declaring html so that it can be written to by the async method (GetHTML)
        static void Main(string[] args)
        {
            Currency Currency1;                 //Initializing our two currency structs
            Currency Currency2;

            GetHTML("https://www.xe.com/currencyconverter/convert/?Amount=1&From=USD&To=EUR");  //Calling the method to get the html that will contain the relative currency values as a string

            while (true)                                                //While loops repeat until either the condition in brackets becomes false, or a "break;" is hit
                                                                        //in this case the condition is brackets is "true" and will never become false, so we're running indefinitely until we hit a break.
                                                                        //This is so the code will keep asking for the currency type we have until we give a valid answer

            {
                Console.WriteLine("What currency do you have?");        //Printing the text to the console line.
                Currency1.Name = Console.ReadLine();                    //Saving the user input into the currency name variable

                if (Currency1.Name.Length == 3)                         //Make sure the user input is the right length. If it is less than 3 then "GetValue" will fail. More than 3 doesnt make sense either.
                {
                    Currency1.Value = GetValue(Currency1.Name, html);   //Call the method "GetValue"
                    if (Currency1.Value != -1)                          //The method "GetValue" is set to return "-1" if no matches are found
                                                                        //No matches will be found if a currency name doesnt exist
                                                                        //the operand "!=" means doesn't (!) equal (=)
                    {
                        break;                                          //If the name is the right lenght and the 
                    }
                    else//If returned currency value is invalid (Function didn't not (sorry for the double-negative, but that's what the code is written as) return -1, show a reason for the error before asking again) 
                    {
                        Console.Clear();
                        Console.Write("Currency name '");       //Console.Write is different from Console.WriteLine because it doesn't start a new line after the text
                        Console.Write(Currency1.Name);          //So the first 3 texts will be on the same line (The two .Writes and the first WriteLine)
                        Console.WriteLine("' is invalid.Please input in 3 - digit notation(USD, CAD, GBP, Etc.)");
                        Console.WriteLine();    //Just to make a two line space between the error message and the "What currency do you have?" message that will be printed immediately after this
                        Console.WriteLine();
                    }
                }
                else//Will execute if the string is not 3 characters long. Kept the same message as above since it still mentions the input must be 3-digits.
                {
                    Console.Clear();
                    Console.Write("Currency name '");
                    Console.Write(Currency1.Name);
                    Console.WriteLine("' is invalid.Please input in 3 - digit notation(USD, CAD, GBP, Etc.)");
                    Console.WriteLine();
                    Console.WriteLine();
                }
            }

            //I didn't do the same thing as above to check that the user input is valid so that you can see why it's important not to leave it out.
            Console.WriteLine("How much " +  Currency1.Name + " do you have to exchange?");
            Currency1.AmountString = Console.ReadLine();
            Currency1.Amount = Convert.ToDecimal(Currency1.AmountString);

            Console.WriteLine("What currency do you want?");
            Currency2.Name = Console.ReadLine();

            Currency2.Value = GetValue(Currency2.Name, html);

            decimal temp = Currency1.Amount / Currency1.Value;

            Currency2.Amount = temp * Currency2.Value;

            Console.Write("Your money is worth ");
            Console.Write(Convert.ToString(Currency2.Amount));
            Console.Write(" in ");
            Console.WriteLine(Currency2.Name);
            Console.ReadLine();
        }
        static async void GetHTML(String URL)       
        {
            HttpClient client = new HttpClient();
            html = await client.GetStringAsync(URL);    //I don't know what "await" does here since I got these couple of lines off of Stack Overflow.
                                                        //Great resource; Websites including that one practically taught me all of the structered text that I do know
        }

        static decimal GetValue(string CurrencyName, string html)       //This function requires two string variables to function, and it spits out one decimal number when it's done
                                                                        //That's why it has to say "decimal" to the left of the method name; Because that's the data type that it returns
        {
            //I like to declare and initialize my variables at the top of each method
            //Variable need to be declared before they can be written to, and initialized before they can be read from
            //Declaring gives the variable a type and name "string ValueString;" would declare it, giving it the name "ValueString" and a data-type of string.
            //Initializing gives it a value. That's what I'm doing when I say "ValueString = """. I'm giving the string the value of <nothing>

            //In all the cases below I'm declaring and initializing in the same line.
            //You don't have to do this. In this case I could only declare Value and ValueStartPos, and since they get a new value before I read from it it wouldn't make a difference

            //C# will complain a lot if it's possible to read a value before it's initialised, so I got used to always initializing it to some default value, but you don't need to do that

            string ValueString = "";           
            decimal Value = 0;
            int htmllength = html.Length;       //html.Length is the amount of characters in the string 
            int ValueStartPos = 0;
            int Iterator = 0;

            //This is a for-loop. It will Iterate (Go over the same code over and over again) a specific amount of times.
            //It's similar to the while loop in that it's iterative, but while loops are good for when you don't know how many times you're going to need to iterate over the code before entering the loop
            //In this case we are going to look at each individual character in the html that we downloaded, so we know the code will need to iterate once per character (460,000 times!)

            //What's happening in the brackets:
            //int i = 0             Initialize an integer named (declared as) "i" with a value of 0
            //i < htmllength        Iterate over the code while i is less than htmllength
            //i++                   After each iteration, increase i by 1

            //++ is the "Increment" operator. All it does in increase the variable by 1. We'll be using it later too. 
            for (int i = 0; i < htmllength; i++)      
            {


                //Here I'm declaring and initializing a variable in the middle of my method. Just wanted to show that you can declare the type of a variable multiple times.
                //No errors come up from saying that c is a character variable over and over.
                //Normally though I'd declare it above with the rest and then only Initialize and change the value down here.

                //As we said above, our string "html" is just a bunch of individual characters in a row
                //What we're doing with "html[i]" is looking at what character is at the "ith" position in the string
                //If we're trying to find the value of CAD, then our goal in this method is to find and return the number that appears after ("CAD":) because in the html
                //all the Values are stored as "CurrencyType":xxx.xxxx,
                //How we're accomplishing this is looking at each individual character in the html string and seeing if we can find the whole prefix in a row
                //After that we're going to find the number that comes after and save that as a string


                //Here is a section of the html string that will show how the value we want is stored
                //"BSD":1,"BTC":0.000022631,"BTN":83.4335678945,"BWP":13.6250377481,"BYN":3.2955419423,"BYR":32955.4194227167,"BZD":2.0160962272,"CAD":1.3589005398,"CDF":2659.0077884638,"CHF":0.880064,"CLF":0.0239000036,"CLP":871.2417452289,"CNH":7

                char c = html[i];   
                if (c == '"')                                       //Is this character "?
                {                                                      
                    c = html[i + 1];                                //If so, is the next character after that C?
                    if (c == CurrencyName[0])
                    {
                        c = html[i + 2];
                        if (c == CurrencyName[1])                   //If so, is the next character after that A?
                        {
                            c = html[i + 3];
                            if (c == CurrencyName[2])               //If so, is the next character after that D?
                            {
                                c = html[i + 4];
                                if (c == '"')                       //If so, is the next character after that another "?
                                {
                                    c = ':';
                                    if (c == html[i + 5])           //If so, is the next character after that :?
                                    {                               //If all the prior if statements are true, then we've found the correct prefix
                                                                    //However we're not completely home free because there are multiple places in the code that say "CAD":
                                                                    //There is only one that says that and is followed by a number, however. (That number being our value relative to usd that we want)
                                        ValueStartPos = i + 6;
                                        if (Char.IsDigit(html[ValueStartPos])){ //This if statement will check that the next character is a number. If so, this is for sure the first character of our value
 
                                            //Here's another loop, this time a while loop though. 
                                            //This will do something similar to the for loop (Iterate over a bunch of characters) except from the starting point found above.
                                            
                                            while (true)                        //The values aren't all the same length, so a while loop is better here
                                            {
                                                if (html[ValueStartPos + Iterator] != ',')                  //If the character isn't 
                                                {
                                                ValueString = ValueString + html[ValueStartPos + Iterator];
                                                }
                                                else
                                                {
                                                Value = Convert.ToDecimal(ValueString);
                                                return Value;
                                                }
                                                Iterator++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return -1M;
        }
    }
}
